<?php

use App\Http\Controllers\BusinessController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SubscriptionController;
use Illuminate\Support\Facades\Route;

Route::inertia('/', 'welcome')->name('home');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('dashboard', DashboardController::class)->name('dashboard');

    Route::middleware('role:owner')->group(function () {
        Route::get('business/profile', [BusinessController::class, 'show'])->name('business.profile');
        Route::post('business/profile', [BusinessController::class, 'store'])->name('business.profile.store');
        Route::put('business/profile', [BusinessController::class, 'update'])->name('business.profile.update');
        Route::get('business/subscriptions', [SubscriptionController::class, 'index'])->name('business.subscriptions');

        Route::resource('categories', CategoryController::class)->except(['create', 'edit', 'show']);
        Route::resource('products', ProductController::class)->except(['create', 'edit', 'show']);
    });
});

require __DIR__.'/settings.php';
require __DIR__.'/auth.php';
