import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import profile937a89 from './profile'
/**
* @see \App\Http\Controllers\BusinessController::profile
 * @see app/Http/Controllers/BusinessController.php:21
 * @route '/business/profile'
 */
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/business/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessController::profile
 * @see app/Http/Controllers/BusinessController.php:21
 * @route '/business/profile'
 */
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessController::profile
 * @see app/Http/Controllers/BusinessController.php:21
 * @route '/business/profile'
 */
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BusinessController::profile
 * @see app/Http/Controllers/BusinessController.php:21
 * @route '/business/profile'
 */
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BusinessController::profile
 * @see app/Http/Controllers/BusinessController.php:21
 * @route '/business/profile'
 */
    const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: profile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BusinessController::profile
 * @see app/Http/Controllers/BusinessController.php:21
 * @route '/business/profile'
 */
        profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BusinessController::profile
 * @see app/Http/Controllers/BusinessController.php:21
 * @route '/business/profile'
 */
        profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    profile.form = profileForm
/**
* @see \App\Http\Controllers\SubscriptionController::subscriptions
 * @see app/Http/Controllers/SubscriptionController.php:13
 * @route '/business/subscriptions'
 */
export const subscriptions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subscriptions.url(options),
    method: 'get',
})

subscriptions.definition = {
    methods: ["get","head"],
    url: '/business/subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::subscriptions
 * @see app/Http/Controllers/SubscriptionController.php:13
 * @route '/business/subscriptions'
 */
subscriptions.url = (options?: RouteQueryOptions) => {
    return subscriptions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::subscriptions
 * @see app/Http/Controllers/SubscriptionController.php:13
 * @route '/business/subscriptions'
 */
subscriptions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: subscriptions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::subscriptions
 * @see app/Http/Controllers/SubscriptionController.php:13
 * @route '/business/subscriptions'
 */
subscriptions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: subscriptions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::subscriptions
 * @see app/Http/Controllers/SubscriptionController.php:13
 * @route '/business/subscriptions'
 */
    const subscriptionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: subscriptions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::subscriptions
 * @see app/Http/Controllers/SubscriptionController.php:13
 * @route '/business/subscriptions'
 */
        subscriptionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subscriptions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::subscriptions
 * @see app/Http/Controllers/SubscriptionController.php:13
 * @route '/business/subscriptions'
 */
        subscriptionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: subscriptions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    subscriptions.form = subscriptionsForm
const business = {
    profile: Object.assign(profile, profile937a89),
subscriptions: Object.assign(subscriptions, subscriptions),
}

export default business