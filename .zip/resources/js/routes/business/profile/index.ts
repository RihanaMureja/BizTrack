import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:29
 * @route '/business/profile'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/business/profile',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:29
 * @route '/business/profile'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:29
 * @route '/business/profile'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:29
 * @route '/business/profile'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:29
 * @route '/business/profile'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:36
 * @route '/business/profile'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/business/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:36
 * @route '/business/profile'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:36
 * @route '/business/profile'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:36
 * @route '/business/profile'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:36
 * @route '/business/profile'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const profile = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
}

export default profile