import Api from './Api'
import DashboardController from './DashboardController'
import BusinessController from './BusinessController'
import SubscriptionController from './SubscriptionController'
import CategoryController from './CategoryController'
import ProductController from './ProductController'
import Settings from './Settings'
const Controllers = {
    Api: Object.assign(Api, Api),
DashboardController: Object.assign(DashboardController, DashboardController),
BusinessController: Object.assign(BusinessController, BusinessController),
SubscriptionController: Object.assign(SubscriptionController, SubscriptionController),
CategoryController: Object.assign(CategoryController, CategoryController),
ProductController: Object.assign(ProductController, ProductController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers