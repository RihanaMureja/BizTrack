import HealthController from './HealthController'
const V1 = {
    HealthController: Object.assign(HealthController, HealthController),
}

export default V1