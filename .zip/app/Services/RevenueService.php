<?php

namespace App\Services;

use App\Models\Business;
use Illuminate\Support\Facades\Schema;

class RevenueService
{
    public function todayRevenue(?Business $business = null): float
    {
        if (! Schema::hasTable('sales')) {
            return 0.0;
        }

        return 0.0;
    }

    public function todayExpenses(?Business $business = null): float
    {
        if (! Schema::hasTable('expenses')) {
            return 0.0;
        }

        return 0.0;
    }

    public function todayProfit(?Business $business = null): float
    {
        return $this->todayRevenue($business) - $this->todayExpenses($business);
    }
}
