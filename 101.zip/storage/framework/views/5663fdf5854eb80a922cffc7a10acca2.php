<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Asku PC\Herd\BizTrack-main\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>