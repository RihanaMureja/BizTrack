<?php

use App\Http\Controllers\BusinessController;
use App\Http\Controllers\Settings\AppearanceController;
use App\Http\Controllers\Settings\ProfileController;
use App\Http\Controllers\Settings\SecurityController;
use App\Http\Controllers\SecurityQuestionController;
use App\Http\Controllers\SettingsController;
use Illuminate\Auth\Middleware\RequirePassword;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth'])->group(function () {
    Route::redirect('settings', '/settings/profile');

    Route::get('settings/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('settings/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::get('settings/preferences', [SettingsController::class, 'edit'])->name('preferences.edit');
    Route::put('settings/preferences', [SettingsController::class, 'update'])->name('preferences.update');
    Route::get('settings/security-questions', [SecurityQuestionController::class, 'edit'])->name('security-questions.edit');
    Route::post('settings/security-questions', [SecurityQuestionController::class, 'store'])->name('security-questions.store');
});

Route::middleware(['auth', 'verified'])->group(function () {
    Route::delete('settings/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::middleware('role:owner')->group(function () {
        Route::get('settings/business', [BusinessController::class, 'settings'])->name('settings.business.edit');
        Route::post('settings/business', [BusinessController::class, 'store'])->name('settings.business.store');
        Route::put('settings/business', [BusinessController::class, 'update'])->name('settings.business.update');
    });

    Route::get('settings/security', [SecurityController::class, 'edit'])
        ->middleware(RequirePassword::class)
        ->name('security.edit');

    Route::put('settings/password', [SecurityController::class, 'update'])
        ->middleware('throttle:6,1')
        ->name('user-password.update');

    Route::get('settings/appearance', [AppearanceController::class, 'edit'])->name('appearance.edit');
    Route::put('settings/appearance', [AppearanceController::class, 'update'])->name('appearance.update');
});

Route::get('.well-known/passkey-endpoints', function () {
    return response()->json([
        'enroll' => route('security.edit'),
        'manage' => route('security.edit'),
    ]);
})->name('well-known.passkeys');
