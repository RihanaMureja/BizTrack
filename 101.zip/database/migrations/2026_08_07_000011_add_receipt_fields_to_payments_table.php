<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table): void {
            if (! Schema::hasColumn('payments', 'receipt_number')) {
                $table->string('receipt_number')->nullable()->unique()->after('payment_number');
            }

            if (! Schema::hasColumn('payments', 'qr_payload')) {
                $table->json('qr_payload')->nullable()->after('gateway_reference');
            }
        });
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table): void {
            if (Schema::hasColumn('payments', 'receipt_number')) {
                $table->dropUnique(['receipt_number']);
                $table->dropColumn('receipt_number');
            }

            if (Schema::hasColumn('payments', 'qr_payload')) {
                $table->dropColumn('qr_payload');
            }
        });
    }
};
