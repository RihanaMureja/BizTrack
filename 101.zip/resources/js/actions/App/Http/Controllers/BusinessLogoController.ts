import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessLogoController::show
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
export const show = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/businesses/{business}/logo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessLogoController::show
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
show.url = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { business: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { business: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    business: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        business: typeof args.business === 'object'
                ? args.business.id
                : args.business,
                }

    return show.definition.url
            .replace('{business}', parsedArgs.business.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessLogoController::show
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
show.get = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BusinessLogoController::show
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
show.head = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BusinessLogoController::show
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
    const showForm = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BusinessLogoController::show
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
        showForm.get = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BusinessLogoController::show
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
        showForm.head = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const BusinessLogoController = { show }

export default BusinessLogoController