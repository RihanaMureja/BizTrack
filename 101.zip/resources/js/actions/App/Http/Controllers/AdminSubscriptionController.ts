import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminSubscriptionController::activate
 * @see app/Http/Controllers/AdminSubscriptionController.php:58
 * @route '/admin/subscriptions/{subscription}/activate'
 */
export const activate = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activate.url(args, options),
    method: 'post',
})

activate.definition = {
    methods: ["post"],
    url: '/admin/subscriptions/{subscription}/activate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminSubscriptionController::activate
 * @see app/Http/Controllers/AdminSubscriptionController.php:58
 * @route '/admin/subscriptions/{subscription}/activate'
 */
activate.url = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscription: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscription: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscription: typeof args.subscription === 'object'
                ? args.subscription.id
                : args.subscription,
                }

    return activate.definition.url
            .replace('{subscription}', parsedArgs.subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminSubscriptionController::activate
 * @see app/Http/Controllers/AdminSubscriptionController.php:58
 * @route '/admin/subscriptions/{subscription}/activate'
 */
activate.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminSubscriptionController::activate
 * @see app/Http/Controllers/AdminSubscriptionController.php:58
 * @route '/admin/subscriptions/{subscription}/activate'
 */
    const activateForm = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: activate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminSubscriptionController::activate
 * @see app/Http/Controllers/AdminSubscriptionController.php:58
 * @route '/admin/subscriptions/{subscription}/activate'
 */
        activateForm.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: activate.url(args, options),
            method: 'post',
        })
    
    activate.form = activateForm
/**
* @see \App\Http\Controllers\AdminSubscriptionController::deactivate
 * @see app/Http/Controllers/AdminSubscriptionController.php:68
 * @route '/admin/subscriptions/{subscription}/deactivate'
 */
export const deactivate = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deactivate.url(args, options),
    method: 'post',
})

deactivate.definition = {
    methods: ["post"],
    url: '/admin/subscriptions/{subscription}/deactivate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminSubscriptionController::deactivate
 * @see app/Http/Controllers/AdminSubscriptionController.php:68
 * @route '/admin/subscriptions/{subscription}/deactivate'
 */
deactivate.url = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscription: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscription: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscription: typeof args.subscription === 'object'
                ? args.subscription.id
                : args.subscription,
                }

    return deactivate.definition.url
            .replace('{subscription}', parsedArgs.subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminSubscriptionController::deactivate
 * @see app/Http/Controllers/AdminSubscriptionController.php:68
 * @route '/admin/subscriptions/{subscription}/deactivate'
 */
deactivate.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deactivate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminSubscriptionController::deactivate
 * @see app/Http/Controllers/AdminSubscriptionController.php:68
 * @route '/admin/subscriptions/{subscription}/deactivate'
 */
    const deactivateForm = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deactivate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminSubscriptionController::deactivate
 * @see app/Http/Controllers/AdminSubscriptionController.php:68
 * @route '/admin/subscriptions/{subscription}/deactivate'
 */
        deactivateForm.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deactivate.url(args, options),
            method: 'post',
        })
    
    deactivate.form = deactivateForm
/**
* @see \App\Http\Controllers\AdminSubscriptionController::index
 * @see app/Http/Controllers/AdminSubscriptionController.php:22
 * @route '/admin/subscriptions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminSubscriptionController::index
 * @see app/Http/Controllers/AdminSubscriptionController.php:22
 * @route '/admin/subscriptions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminSubscriptionController::index
 * @see app/Http/Controllers/AdminSubscriptionController.php:22
 * @route '/admin/subscriptions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminSubscriptionController::index
 * @see app/Http/Controllers/AdminSubscriptionController.php:22
 * @route '/admin/subscriptions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminSubscriptionController::index
 * @see app/Http/Controllers/AdminSubscriptionController.php:22
 * @route '/admin/subscriptions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminSubscriptionController::index
 * @see app/Http/Controllers/AdminSubscriptionController.php:22
 * @route '/admin/subscriptions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminSubscriptionController::index
 * @see app/Http/Controllers/AdminSubscriptionController.php:22
 * @route '/admin/subscriptions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminSubscriptionController::store
 * @see app/Http/Controllers/AdminSubscriptionController.php:38
 * @route '/admin/subscriptions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/subscriptions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminSubscriptionController::store
 * @see app/Http/Controllers/AdminSubscriptionController.php:38
 * @route '/admin/subscriptions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminSubscriptionController::store
 * @see app/Http/Controllers/AdminSubscriptionController.php:38
 * @route '/admin/subscriptions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminSubscriptionController::store
 * @see app/Http/Controllers/AdminSubscriptionController.php:38
 * @route '/admin/subscriptions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminSubscriptionController::store
 * @see app/Http/Controllers/AdminSubscriptionController.php:38
 * @route '/admin/subscriptions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminSubscriptionController::update
 * @see app/Http/Controllers/AdminSubscriptionController.php:48
 * @route '/admin/subscriptions/{subscription}'
 */
export const update = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/subscriptions/{subscription}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\AdminSubscriptionController::update
 * @see app/Http/Controllers/AdminSubscriptionController.php:48
 * @route '/admin/subscriptions/{subscription}'
 */
update.url = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscription: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscription: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscription: typeof args.subscription === 'object'
                ? args.subscription.id
                : args.subscription,
                }

    return update.definition.url
            .replace('{subscription}', parsedArgs.subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminSubscriptionController::update
 * @see app/Http/Controllers/AdminSubscriptionController.php:48
 * @route '/admin/subscriptions/{subscription}'
 */
update.put = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminSubscriptionController::update
 * @see app/Http/Controllers/AdminSubscriptionController.php:48
 * @route '/admin/subscriptions/{subscription}'
 */
update.patch = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AdminSubscriptionController::update
 * @see app/Http/Controllers/AdminSubscriptionController.php:48
 * @route '/admin/subscriptions/{subscription}'
 */
    const updateForm = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminSubscriptionController::update
 * @see app/Http/Controllers/AdminSubscriptionController.php:48
 * @route '/admin/subscriptions/{subscription}'
 */
        updateForm.put = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminSubscriptionController::update
 * @see app/Http/Controllers/AdminSubscriptionController.php:48
 * @route '/admin/subscriptions/{subscription}'
 */
        updateForm.patch = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const AdminSubscriptionController = { activate, deactivate, index, store, update }

export default AdminSubscriptionController