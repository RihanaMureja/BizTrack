import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\InventoryBatchController::index
 * @see app/Http/Controllers/InventoryBatchController.php:17
 * @route '/inventory/{inventory}/batches'
 */
export const index = (args: { inventory: number | { id: number } } | [inventory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/inventory/{inventory}/batches',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InventoryBatchController::index
 * @see app/Http/Controllers/InventoryBatchController.php:17
 * @route '/inventory/{inventory}/batches'
 */
index.url = (args: { inventory: number | { id: number } } | [inventory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inventory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { inventory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    inventory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventory: typeof args.inventory === 'object'
                ? args.inventory.id
                : args.inventory,
                }

    return index.definition.url
            .replace('{inventory}', parsedArgs.inventory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryBatchController::index
 * @see app/Http/Controllers/InventoryBatchController.php:17
 * @route '/inventory/{inventory}/batches'
 */
index.get = (args: { inventory: number | { id: number } } | [inventory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InventoryBatchController::index
 * @see app/Http/Controllers/InventoryBatchController.php:17
 * @route '/inventory/{inventory}/batches'
 */
index.head = (args: { inventory: number | { id: number } } | [inventory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InventoryBatchController::index
 * @see app/Http/Controllers/InventoryBatchController.php:17
 * @route '/inventory/{inventory}/batches'
 */
    const indexForm = (args: { inventory: number | { id: number } } | [inventory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InventoryBatchController::index
 * @see app/Http/Controllers/InventoryBatchController.php:17
 * @route '/inventory/{inventory}/batches'
 */
        indexForm.get = (args: { inventory: number | { id: number } } | [inventory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InventoryBatchController::index
 * @see app/Http/Controllers/InventoryBatchController.php:17
 * @route '/inventory/{inventory}/batches'
 */
        indexForm.head = (args: { inventory: number | { id: number } } | [inventory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const InventoryBatchController = { index }

export default InventoryBatchController