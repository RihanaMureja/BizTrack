import ForcePasswordResetController from './ForcePasswordResetController'
const Auth = {
    ForcePasswordResetController: Object.assign(ForcePasswordResetController, ForcePasswordResetController),
}

export default Auth