import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ExpenseCategoryController::store
 * @see app/Http/Controllers/ExpenseCategoryController.php:16
 * @route '/expense-categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/expense-categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ExpenseCategoryController::store
 * @see app/Http/Controllers/ExpenseCategoryController.php:16
 * @route '/expense-categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpenseCategoryController::store
 * @see app/Http/Controllers/ExpenseCategoryController.php:16
 * @route '/expense-categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ExpenseCategoryController::store
 * @see app/Http/Controllers/ExpenseCategoryController.php:16
 * @route '/expense-categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ExpenseCategoryController::store
 * @see app/Http/Controllers/ExpenseCategoryController.php:16
 * @route '/expense-categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ExpenseCategoryController::update
 * @see app/Http/Controllers/ExpenseCategoryController.php:28
 * @route '/expense-categories/{expenseCategory}'
 */
export const update = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/expense-categories/{expenseCategory}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ExpenseCategoryController::update
 * @see app/Http/Controllers/ExpenseCategoryController.php:28
 * @route '/expense-categories/{expenseCategory}'
 */
update.url = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expenseCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { expenseCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    expenseCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        expenseCategory: typeof args.expenseCategory === 'object'
                ? args.expenseCategory.id
                : args.expenseCategory,
                }

    return update.definition.url
            .replace('{expenseCategory}', parsedArgs.expenseCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpenseCategoryController::update
 * @see app/Http/Controllers/ExpenseCategoryController.php:28
 * @route '/expense-categories/{expenseCategory}'
 */
update.put = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\ExpenseCategoryController::update
 * @see app/Http/Controllers/ExpenseCategoryController.php:28
 * @route '/expense-categories/{expenseCategory}'
 */
update.patch = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ExpenseCategoryController::update
 * @see app/Http/Controllers/ExpenseCategoryController.php:28
 * @route '/expense-categories/{expenseCategory}'
 */
    const updateForm = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ExpenseCategoryController::update
 * @see app/Http/Controllers/ExpenseCategoryController.php:28
 * @route '/expense-categories/{expenseCategory}'
 */
        updateForm.put = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\ExpenseCategoryController::update
 * @see app/Http/Controllers/ExpenseCategoryController.php:28
 * @route '/expense-categories/{expenseCategory}'
 */
        updateForm.patch = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ExpenseCategoryController::destroy
 * @see app/Http/Controllers/ExpenseCategoryController.php:40
 * @route '/expense-categories/{expenseCategory}'
 */
export const destroy = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/expense-categories/{expenseCategory}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ExpenseCategoryController::destroy
 * @see app/Http/Controllers/ExpenseCategoryController.php:40
 * @route '/expense-categories/{expenseCategory}'
 */
destroy.url = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expenseCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { expenseCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    expenseCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        expenseCategory: typeof args.expenseCategory === 'object'
                ? args.expenseCategory.id
                : args.expenseCategory,
                }

    return destroy.definition.url
            .replace('{expenseCategory}', parsedArgs.expenseCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ExpenseCategoryController::destroy
 * @see app/Http/Controllers/ExpenseCategoryController.php:40
 * @route '/expense-categories/{expenseCategory}'
 */
destroy.delete = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ExpenseCategoryController::destroy
 * @see app/Http/Controllers/ExpenseCategoryController.php:40
 * @route '/expense-categories/{expenseCategory}'
 */
    const destroyForm = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ExpenseCategoryController::destroy
 * @see app/Http/Controllers/ExpenseCategoryController.php:40
 * @route '/expense-categories/{expenseCategory}'
 */
        destroyForm.delete = (args: { expenseCategory: number | { id: number } } | [expenseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ExpenseCategoryController = { store, update, destroy }

export default ExpenseCategoryController