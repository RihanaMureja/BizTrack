import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
const SuperAdminController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SuperAdminController.url(options),
    method: 'get',
})

SuperAdminController.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
SuperAdminController.url = (options?: RouteQueryOptions) => {
    return SuperAdminController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
SuperAdminController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SuperAdminController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
SuperAdminController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SuperAdminController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
    const SuperAdminControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: SuperAdminController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
        SuperAdminControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: SuperAdminController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
        SuperAdminControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: SuperAdminController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    SuperAdminController.form = SuperAdminControllerForm
export default SuperAdminController