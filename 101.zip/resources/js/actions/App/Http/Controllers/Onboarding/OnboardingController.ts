import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/onboarding',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
export const businessProfile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: businessProfile.url(options),
    method: 'get',
})

businessProfile.definition = {
    methods: ["get","head"],
    url: '/onboarding/business-profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
businessProfile.url = (options?: RouteQueryOptions) => {
    return businessProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
businessProfile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: businessProfile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
businessProfile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: businessProfile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
    const businessProfileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: businessProfile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
        businessProfileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: businessProfile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
        businessProfileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: businessProfile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    businessProfile.form = businessProfileForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::storeBusinessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
export const storeBusinessProfile = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBusinessProfile.url(options),
    method: 'post',
})

storeBusinessProfile.definition = {
    methods: ["post"],
    url: '/onboarding/business-profile',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::storeBusinessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
storeBusinessProfile.url = (options?: RouteQueryOptions) => {
    return storeBusinessProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::storeBusinessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
storeBusinessProfile.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBusinessProfile.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::storeBusinessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
    const storeBusinessProfileForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeBusinessProfile.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::storeBusinessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
        storeBusinessProfileForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeBusinessProfile.url(options),
            method: 'post',
        })
    
    storeBusinessProfile.form = storeBusinessProfileForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
export const verifyPhone = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyPhone.url(options),
    method: 'get',
})

verifyPhone.definition = {
    methods: ["get","head"],
    url: '/onboarding/verify-phone',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
verifyPhone.url = (options?: RouteQueryOptions) => {
    return verifyPhone.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
verifyPhone.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyPhone.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
verifyPhone.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verifyPhone.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
    const verifyPhoneForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verifyPhone.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
        verifyPhoneForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyPhone.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
        verifyPhoneForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyPhone.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verifyPhone.form = verifyPhoneForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::sendPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
export const sendPhoneCode = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendPhoneCode.url(options),
    method: 'post',
})

sendPhoneCode.definition = {
    methods: ["post"],
    url: '/onboarding/verify-phone/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::sendPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
sendPhoneCode.url = (options?: RouteQueryOptions) => {
    return sendPhoneCode.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::sendPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
sendPhoneCode.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendPhoneCode.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::sendPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
    const sendPhoneCodeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendPhoneCode.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::sendPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
        sendPhoneCodeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendPhoneCode.url(options),
            method: 'post',
        })
    
    sendPhoneCode.form = sendPhoneCodeForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
export const verifyPhoneCode = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyPhoneCode.url(options),
    method: 'post',
})

verifyPhoneCode.definition = {
    methods: ["post"],
    url: '/onboarding/verify-phone/confirm',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
verifyPhoneCode.url = (options?: RouteQueryOptions) => {
    return verifyPhoneCode.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
verifyPhoneCode.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyPhoneCode.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
    const verifyPhoneCodeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verifyPhoneCode.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhoneCode
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
        verifyPhoneCodeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verifyPhoneCode.url(options),
            method: 'post',
        })
    
    verifyPhoneCode.form = verifyPhoneCodeForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
export const choosePlan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choosePlan.url(options),
    method: 'get',
})

choosePlan.definition = {
    methods: ["get","head"],
    url: '/onboarding/choose-plan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
choosePlan.url = (options?: RouteQueryOptions) => {
    return choosePlan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
choosePlan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choosePlan.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
choosePlan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: choosePlan.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
    const choosePlanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: choosePlan.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
        choosePlanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choosePlan.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
        choosePlanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choosePlan.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    choosePlan.form = choosePlanForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activatePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
export const activatePlan = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activatePlan.url(args, options),
    method: 'post',
})

activatePlan.definition = {
    methods: ["post"],
    url: '/onboarding/plans/{subscription}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activatePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
activatePlan.url = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscription: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscription: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscription: typeof args.subscription === 'object'
                ? args.subscription.id
                : args.subscription,
                }

    return activatePlan.definition.url
            .replace('{subscription}', parsedArgs.subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activatePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
activatePlan.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activatePlan.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activatePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
    const activatePlanForm = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: activatePlan.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activatePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
        activatePlanForm.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: activatePlan.url(args, options),
            method: 'post',
        })
    
    activatePlan.form = activatePlanForm
const OnboardingController = { index, businessProfile, storeBusinessProfile, verifyPhone, sendPhoneCode, verifyPhoneCode, choosePlan, activatePlan }

export default OnboardingController