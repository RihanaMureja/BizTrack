import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Onboarding\TrialActivationController::store
 * @see app/Http/Controllers/Onboarding/TrialActivationController.php:14
 * @route '/onboarding/trial'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/onboarding/trial',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\TrialActivationController::store
 * @see app/Http/Controllers/Onboarding/TrialActivationController.php:14
 * @route '/onboarding/trial'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\TrialActivationController::store
 * @see app/Http/Controllers/Onboarding/TrialActivationController.php:14
 * @route '/onboarding/trial'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\TrialActivationController::store
 * @see app/Http/Controllers/Onboarding/TrialActivationController.php:14
 * @route '/onboarding/trial'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\TrialActivationController::store
 * @see app/Http/Controllers/Onboarding/TrialActivationController.php:14
 * @route '/onboarding/trial'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const TrialActivationController = { store }

export default TrialActivationController