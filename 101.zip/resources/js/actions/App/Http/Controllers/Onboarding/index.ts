import OnboardingController from './OnboardingController'
import TrialActivationController from './TrialActivationController'
const Onboarding = {
    OnboardingController: Object.assign(OnboardingController, OnboardingController),
TrialActivationController: Object.assign(TrialActivationController, TrialActivationController),
}

export default Onboarding