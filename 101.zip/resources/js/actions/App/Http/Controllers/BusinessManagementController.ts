import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/businesses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\BusinessManagementController::updateSubscription
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
export const updateSubscription = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateSubscription.url(args, options),
    method: 'put',
})

updateSubscription.definition = {
    methods: ["put"],
    url: '/admin/businesses/{business}/subscription',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BusinessManagementController::updateSubscription
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
updateSubscription.url = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { business: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { business: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    business: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        business: typeof args.business === 'object'
                ? args.business.id
                : args.business,
                }

    return updateSubscription.definition.url
            .replace('{business}', parsedArgs.business.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessManagementController::updateSubscription
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
updateSubscription.put = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateSubscription.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\BusinessManagementController::updateSubscription
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
    const updateSubscriptionForm = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSubscription.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessManagementController::updateSubscription
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
        updateSubscriptionForm.put = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSubscription.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateSubscription.form = updateSubscriptionForm
const BusinessManagementController = { index, updateSubscription }

export default BusinessManagementController