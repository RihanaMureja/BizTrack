import Api from './Api'
import Onboarding from './Onboarding'
import BusinessLogoController from './BusinessLogoController'
import BusinessVerificationDocumentController from './BusinessVerificationDocumentController'
import DashboardController from './DashboardController'
import AuditLogController from './AuditLogController'
import SuperAdminController from './SuperAdminController'
import BusinessManagementController from './BusinessManagementController'
import UserManagementController from './UserManagementController'
import AdminSubscriptionController from './AdminSubscriptionController'
import RoleController from './RoleController'
import PermissionController from './PermissionController'
import SubscriptionController from './SubscriptionController'
import CategoryController from './CategoryController'
import ProductCodeController from './ProductCodeController'
import ProductController from './ProductController'
import InventoryController from './InventoryController'
import InventoryBatchController from './InventoryBatchController'
import InventoryTransactionController from './InventoryTransactionController'
import CashierController from './CashierController'
import BusinessRoleController from './BusinessRoleController'
import ExpenseCategoryController from './ExpenseCategoryController'
import ExpenseController from './ExpenseController'
import ProductReportController from './ProductReportController'
import ReportController from './ReportController'
import CustomerController from './CustomerController'
import CustomerCreditController from './CustomerCreditController'
import CreditDiscountController from './CreditDiscountController'
import SaleController from './SaleController'
import CheckoutController from './CheckoutController'
import PaymentController from './PaymentController'
import PaymentReceiptController from './PaymentReceiptController'
import NotificationController from './NotificationController'
import Settings from './Settings'
import SettingsController from './SettingsController'
import SecurityQuestionController from './SecurityQuestionController'
import BusinessController from './BusinessController'
import Auth from './Auth'
const Controllers = {
    Api: Object.assign(Api, Api),
Onboarding: Object.assign(Onboarding, Onboarding),
BusinessLogoController: Object.assign(BusinessLogoController, BusinessLogoController),
BusinessVerificationDocumentController: Object.assign(BusinessVerificationDocumentController, BusinessVerificationDocumentController),
DashboardController: Object.assign(DashboardController, DashboardController),
AuditLogController: Object.assign(AuditLogController, AuditLogController),
SuperAdminController: Object.assign(SuperAdminController, SuperAdminController),
BusinessManagementController: Object.assign(BusinessManagementController, BusinessManagementController),
UserManagementController: Object.assign(UserManagementController, UserManagementController),
AdminSubscriptionController: Object.assign(AdminSubscriptionController, AdminSubscriptionController),
RoleController: Object.assign(RoleController, RoleController),
PermissionController: Object.assign(PermissionController, PermissionController),
SubscriptionController: Object.assign(SubscriptionController, SubscriptionController),
CategoryController: Object.assign(CategoryController, CategoryController),
ProductCodeController: Object.assign(ProductCodeController, ProductCodeController),
ProductController: Object.assign(ProductController, ProductController),
InventoryController: Object.assign(InventoryController, InventoryController),
InventoryBatchController: Object.assign(InventoryBatchController, InventoryBatchController),
InventoryTransactionController: Object.assign(InventoryTransactionController, InventoryTransactionController),
CashierController: Object.assign(CashierController, CashierController),
BusinessRoleController: Object.assign(BusinessRoleController, BusinessRoleController),
ExpenseCategoryController: Object.assign(ExpenseCategoryController, ExpenseCategoryController),
ExpenseController: Object.assign(ExpenseController, ExpenseController),
ProductReportController: Object.assign(ProductReportController, ProductReportController),
ReportController: Object.assign(ReportController, ReportController),
CustomerController: Object.assign(CustomerController, CustomerController),
CustomerCreditController: Object.assign(CustomerCreditController, CustomerCreditController),
CreditDiscountController: Object.assign(CreditDiscountController, CreditDiscountController),
SaleController: Object.assign(SaleController, SaleController),
CheckoutController: Object.assign(CheckoutController, CheckoutController),
PaymentController: Object.assign(PaymentController, PaymentController),
PaymentReceiptController: Object.assign(PaymentReceiptController, PaymentReceiptController),
NotificationController: Object.assign(NotificationController, NotificationController),
Settings: Object.assign(Settings, Settings),
SettingsController: Object.assign(SettingsController, SettingsController),
SecurityQuestionController: Object.assign(SecurityQuestionController, SecurityQuestionController),
BusinessController: Object.assign(BusinessController, BusinessController),
Auth: Object.assign(Auth, Auth),
}

export default Controllers