export type User = {
    id: number;
    business_id?: number | null;
    first_name?: string | null;
    last_name?: string | null;
    name: string;
    email: string;
    phone?: string | null;
    role: 'super_admin' | 'owner' | 'cashier';
    role_label: string;
    status: 'active' | 'inactive';
    avatar?: string;
    business_logo?: string | null;
    display_business_name?: string | null;
    email_verified_at: string | null;
    two_factor_enabled?: boolean;
    created_at: string;
    updated_at: string;
    [key: string]: unknown;
};

export type Auth = {
    user: User;
};

/* @chisel-passkeys */
export type Passkey = {
    id: number;
    name: string;
    authenticator: string | null;
    created_at_diff: string;
    last_used_at_diff: string | null;
};
/* @end-chisel-passkeys */

export type TwoFactorSetupData = {
    svg: string;
    url: string;
};

export type TwoFactorSecretKey = {
    secretKey: string;
};
