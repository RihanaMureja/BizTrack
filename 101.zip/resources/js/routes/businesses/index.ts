import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessLogoController::logo
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
export const logo = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logo.url(args, options),
    method: 'get',
})

logo.definition = {
    methods: ["get","head"],
    url: '/businesses/{business}/logo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessLogoController::logo
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
logo.url = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { business: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { business: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    business: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        business: typeof args.business === 'object'
                ? args.business.id
                : args.business,
                }

    return logo.definition.url
            .replace('{business}', parsedArgs.business.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessLogoController::logo
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
logo.get = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logo.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BusinessLogoController::logo
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
logo.head = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logo.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BusinessLogoController::logo
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
    const logoForm = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: logo.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BusinessLogoController::logo
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
        logoForm.get = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logo.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BusinessLogoController::logo
 * @see app/Http/Controllers/BusinessLogoController.php:12
 * @route '/businesses/{business}/logo'
 */
        logoForm.head = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logo.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    logo.form = logoForm
const businesses = {
    logo: Object.assign(logo, logo),
}

export default businesses