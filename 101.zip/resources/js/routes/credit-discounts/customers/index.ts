import creditLimit from './credit-limit'
const customers = {
    creditLimit: Object.assign(creditLimit, creditLimit),
}

export default customers