import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CreditDiscountController::store
 * @see app/Http/Controllers/CreditDiscountController.php:36
 * @route '/credit-discounts/rules'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/credit-discounts/rules',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CreditDiscountController::store
 * @see app/Http/Controllers/CreditDiscountController.php:36
 * @route '/credit-discounts/rules'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CreditDiscountController::store
 * @see app/Http/Controllers/CreditDiscountController.php:36
 * @route '/credit-discounts/rules'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CreditDiscountController::store
 * @see app/Http/Controllers/CreditDiscountController.php:36
 * @route '/credit-discounts/rules'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CreditDiscountController::store
 * @see app/Http/Controllers/CreditDiscountController.php:36
 * @route '/credit-discounts/rules'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CreditDiscountController::update
 * @see app/Http/Controllers/CreditDiscountController.php:49
 * @route '/credit-discounts/rules/{discountRule}'
 */
export const update = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/credit-discounts/rules/{discountRule}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CreditDiscountController::update
 * @see app/Http/Controllers/CreditDiscountController.php:49
 * @route '/credit-discounts/rules/{discountRule}'
 */
update.url = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { discountRule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { discountRule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    discountRule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        discountRule: typeof args.discountRule === 'object'
                ? args.discountRule.id
                : args.discountRule,
                }

    return update.definition.url
            .replace('{discountRule}', parsedArgs.discountRule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CreditDiscountController::update
 * @see app/Http/Controllers/CreditDiscountController.php:49
 * @route '/credit-discounts/rules/{discountRule}'
 */
update.put = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CreditDiscountController::update
 * @see app/Http/Controllers/CreditDiscountController.php:49
 * @route '/credit-discounts/rules/{discountRule}'
 */
    const updateForm = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CreditDiscountController::update
 * @see app/Http/Controllers/CreditDiscountController.php:49
 * @route '/credit-discounts/rules/{discountRule}'
 */
        updateForm.put = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CreditDiscountController::destroy
 * @see app/Http/Controllers/CreditDiscountController.php:62
 * @route '/credit-discounts/rules/{discountRule}'
 */
export const destroy = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/credit-discounts/rules/{discountRule}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CreditDiscountController::destroy
 * @see app/Http/Controllers/CreditDiscountController.php:62
 * @route '/credit-discounts/rules/{discountRule}'
 */
destroy.url = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { discountRule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { discountRule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    discountRule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        discountRule: typeof args.discountRule === 'object'
                ? args.discountRule.id
                : args.discountRule,
                }

    return destroy.definition.url
            .replace('{discountRule}', parsedArgs.discountRule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CreditDiscountController::destroy
 * @see app/Http/Controllers/CreditDiscountController.php:62
 * @route '/credit-discounts/rules/{discountRule}'
 */
destroy.delete = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CreditDiscountController::destroy
 * @see app/Http/Controllers/CreditDiscountController.php:62
 * @route '/credit-discounts/rules/{discountRule}'
 */
    const destroyForm = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CreditDiscountController::destroy
 * @see app/Http/Controllers/CreditDiscountController.php:62
 * @route '/credit-discounts/rules/{discountRule}'
 */
        destroyForm.delete = (args: { discountRule: number | { id: number } } | [discountRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const rules = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default rules