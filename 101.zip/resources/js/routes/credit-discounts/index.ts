import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import rules from './rules'
import customers from './customers'
/**
* @see \App\Http\Controllers\CreditDiscountController::index
 * @see app/Http/Controllers/CreditDiscountController.php:26
 * @route '/credit-discounts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/credit-discounts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CreditDiscountController::index
 * @see app/Http/Controllers/CreditDiscountController.php:26
 * @route '/credit-discounts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CreditDiscountController::index
 * @see app/Http/Controllers/CreditDiscountController.php:26
 * @route '/credit-discounts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CreditDiscountController::index
 * @see app/Http/Controllers/CreditDiscountController.php:26
 * @route '/credit-discounts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CreditDiscountController::index
 * @see app/Http/Controllers/CreditDiscountController.php:26
 * @route '/credit-discounts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CreditDiscountController::index
 * @see app/Http/Controllers/CreditDiscountController.php:26
 * @route '/credit-discounts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CreditDiscountController::index
 * @see app/Http/Controllers/CreditDiscountController.php:26
 * @route '/credit-discounts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const creditDiscounts = {
    index: Object.assign(index, index),
rules: Object.assign(rules, rules),
customers: Object.assign(customers, customers),
}

export default creditDiscounts