import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import businessProfile28f1e7 from './business-profile'
import verifyPhoneDc04df from './verify-phone'
import trial from './trial'
import plans from './plans'
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/onboarding',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::index
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:27
 * @route '/onboarding'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
export const businessProfile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: businessProfile.url(options),
    method: 'get',
})

businessProfile.definition = {
    methods: ["get","head"],
    url: '/onboarding/business-profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
businessProfile.url = (options?: RouteQueryOptions) => {
    return businessProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
businessProfile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: businessProfile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
businessProfile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: businessProfile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
    const businessProfileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: businessProfile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
        businessProfileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: businessProfile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::businessProfile
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:32
 * @route '/onboarding/business-profile'
 */
        businessProfileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: businessProfile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    businessProfile.form = businessProfileForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
export const verifyPhone = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyPhone.url(options),
    method: 'get',
})

verifyPhone.definition = {
    methods: ["get","head"],
    url: '/onboarding/verify-phone',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
verifyPhone.url = (options?: RouteQueryOptions) => {
    return verifyPhone.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
verifyPhone.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyPhone.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
verifyPhone.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verifyPhone.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
    const verifyPhoneForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verifyPhone.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
        verifyPhoneForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyPhone.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::verifyPhone
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:50
 * @route '/onboarding/verify-phone'
 */
        verifyPhoneForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyPhone.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verifyPhone.form = verifyPhoneForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
export const choosePlan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choosePlan.url(options),
    method: 'get',
})

choosePlan.definition = {
    methods: ["get","head"],
    url: '/onboarding/choose-plan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
choosePlan.url = (options?: RouteQueryOptions) => {
    return choosePlan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
choosePlan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: choosePlan.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
choosePlan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: choosePlan.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
    const choosePlanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: choosePlan.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
        choosePlanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choosePlan.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::choosePlan
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:77
 * @route '/onboarding/choose-plan'
 */
        choosePlanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: choosePlan.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    choosePlan.form = choosePlanForm
const onboarding = {
    index: Object.assign(index, index),
businessProfile: Object.assign(businessProfile, businessProfile28f1e7),
verifyPhone: Object.assign(verifyPhone, verifyPhoneDc04df),
choosePlan: Object.assign(choosePlan, choosePlan),
trial: Object.assign(trial, trial),
plans: Object.assign(plans, plans),
}

export default onboarding