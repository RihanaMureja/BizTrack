import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::store
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/onboarding/business-profile',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::store
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::store
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::store
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::store
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:43
 * @route '/onboarding/business-profile'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const businessProfile = {
    store: Object.assign(store, store),
}

export default businessProfile