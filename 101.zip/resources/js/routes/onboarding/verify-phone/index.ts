import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::send
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
export const send = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/onboarding/verify-phone/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::send
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
send.url = (options?: RouteQueryOptions) => {
    return send.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::send
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
send.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::send
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
    const sendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::send
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:58
 * @route '/onboarding/verify-phone/send'
 */
        sendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::confirm
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
export const confirm = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirm.url(options),
    method: 'post',
})

confirm.definition = {
    methods: ["post"],
    url: '/onboarding/verify-phone/confirm',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::confirm
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
confirm.url = (options?: RouteQueryOptions) => {
    return confirm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::confirm
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
confirm.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirm.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::confirm
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
    const confirmForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: confirm.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::confirm
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:66
 * @route '/onboarding/verify-phone/confirm'
 */
        confirmForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: confirm.url(options),
            method: 'post',
        })
    
    confirm.form = confirmForm
const verifyPhone = {
    send: Object.assign(send, send),
confirm: Object.assign(confirm, confirm),
}

export default verifyPhone