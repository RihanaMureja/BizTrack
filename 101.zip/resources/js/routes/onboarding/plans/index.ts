import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activate
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
export const activate = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activate.url(args, options),
    method: 'post',
})

activate.definition = {
    methods: ["post"],
    url: '/onboarding/plans/{subscription}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activate
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
activate.url = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscription: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscription: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscription: typeof args.subscription === 'object'
                ? args.subscription.id
                : args.subscription,
                }

    return activate.definition.url
            .replace('{subscription}', parsedArgs.subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activate
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
activate.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activate
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
    const activateForm = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: activate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Onboarding\OnboardingController::activate
 * @see app/Http/Controllers/Onboarding/OnboardingController.php:85
 * @route '/onboarding/plans/{subscription}'
 */
        activateForm.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: activate.url(args, options),
            method: 'post',
        })
    
    activate.form = activateForm
const plans = {
    activate: Object.assign(activate, activate),
}

export default plans