import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ProductController::dismiss
 * @see app/Http/Controllers/ProductController.php:117
 * @route '/product-insights/{productMovementInsight}/dismiss'
 */
export const dismiss = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: dismiss.url(args, options),
    method: 'post',
})

dismiss.definition = {
    methods: ["post"],
    url: '/product-insights/{productMovementInsight}/dismiss',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::dismiss
 * @see app/Http/Controllers/ProductController.php:117
 * @route '/product-insights/{productMovementInsight}/dismiss'
 */
dismiss.url = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productMovementInsight: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { productMovementInsight: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    productMovementInsight: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        productMovementInsight: typeof args.productMovementInsight === 'object'
                ? args.productMovementInsight.id
                : args.productMovementInsight,
                }

    return dismiss.definition.url
            .replace('{productMovementInsight}', parsedArgs.productMovementInsight.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::dismiss
 * @see app/Http/Controllers/ProductController.php:117
 * @route '/product-insights/{productMovementInsight}/dismiss'
 */
dismiss.post = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: dismiss.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProductController::dismiss
 * @see app/Http/Controllers/ProductController.php:117
 * @route '/product-insights/{productMovementInsight}/dismiss'
 */
    const dismissForm = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: dismiss.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProductController::dismiss
 * @see app/Http/Controllers/ProductController.php:117
 * @route '/product-insights/{productMovementInsight}/dismiss'
 */
        dismissForm.post = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: dismiss.url(args, options),
            method: 'post',
        })
    
    dismiss.form = dismissForm
/**
* @see \App\Http\Controllers\ProductController::resolve
 * @see app/Http/Controllers/ProductController.php:126
 * @route '/product-insights/{productMovementInsight}/resolve'
 */
export const resolve = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolve.url(args, options),
    method: 'post',
})

resolve.definition = {
    methods: ["post"],
    url: '/product-insights/{productMovementInsight}/resolve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductController::resolve
 * @see app/Http/Controllers/ProductController.php:126
 * @route '/product-insights/{productMovementInsight}/resolve'
 */
resolve.url = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productMovementInsight: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { productMovementInsight: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    productMovementInsight: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        productMovementInsight: typeof args.productMovementInsight === 'object'
                ? args.productMovementInsight.id
                : args.productMovementInsight,
                }

    return resolve.definition.url
            .replace('{productMovementInsight}', parsedArgs.productMovementInsight.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductController::resolve
 * @see app/Http/Controllers/ProductController.php:126
 * @route '/product-insights/{productMovementInsight}/resolve'
 */
resolve.post = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProductController::resolve
 * @see app/Http/Controllers/ProductController.php:126
 * @route '/product-insights/{productMovementInsight}/resolve'
 */
    const resolveForm = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resolve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProductController::resolve
 * @see app/Http/Controllers/ProductController.php:126
 * @route '/product-insights/{productMovementInsight}/resolve'
 */
        resolveForm.post = (args: { productMovementInsight: number | { id: number } } | [productMovementInsight: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resolve.url(args, options),
            method: 'post',
        })
    
    resolve.form = resolveForm
const productInsights = {
    dismiss: Object.assign(dismiss, dismiss),
resolve: Object.assign(resolve, resolve),
}

export default productInsights