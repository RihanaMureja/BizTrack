import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CashierController::deactivate
 * @see app/Http/Controllers/CashierController.php:72
 * @route '/cashiers/{cashier}/deactivate'
 */
export const deactivate = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deactivate.url(args, options),
    method: 'post',
})

deactivate.definition = {
    methods: ["post"],
    url: '/cashiers/{cashier}/deactivate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CashierController::deactivate
 * @see app/Http/Controllers/CashierController.php:72
 * @route '/cashiers/{cashier}/deactivate'
 */
deactivate.url = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cashier: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cashier: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cashier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cashier: typeof args.cashier === 'object'
                ? args.cashier.id
                : args.cashier,
                }

    return deactivate.definition.url
            .replace('{cashier}', parsedArgs.cashier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CashierController::deactivate
 * @see app/Http/Controllers/CashierController.php:72
 * @route '/cashiers/{cashier}/deactivate'
 */
deactivate.post = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deactivate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CashierController::deactivate
 * @see app/Http/Controllers/CashierController.php:72
 * @route '/cashiers/{cashier}/deactivate'
 */
    const deactivateForm = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deactivate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CashierController::deactivate
 * @see app/Http/Controllers/CashierController.php:72
 * @route '/cashiers/{cashier}/deactivate'
 */
        deactivateForm.post = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deactivate.url(args, options),
            method: 'post',
        })
    
    deactivate.form = deactivateForm
/**
* @see \App\Http\Controllers\CashierController::resetPassword
 * @see app/Http/Controllers/CashierController.php:83
 * @route '/cashiers/{cashier}/reset-password'
 */
export const resetPassword = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(args, options),
    method: 'post',
})

resetPassword.definition = {
    methods: ["post"],
    url: '/cashiers/{cashier}/reset-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CashierController::resetPassword
 * @see app/Http/Controllers/CashierController.php:83
 * @route '/cashiers/{cashier}/reset-password'
 */
resetPassword.url = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cashier: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cashier: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cashier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cashier: typeof args.cashier === 'object'
                ? args.cashier.id
                : args.cashier,
                }

    return resetPassword.definition.url
            .replace('{cashier}', parsedArgs.cashier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CashierController::resetPassword
 * @see app/Http/Controllers/CashierController.php:83
 * @route '/cashiers/{cashier}/reset-password'
 */
resetPassword.post = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CashierController::resetPassword
 * @see app/Http/Controllers/CashierController.php:83
 * @route '/cashiers/{cashier}/reset-password'
 */
    const resetPasswordForm = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetPassword.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CashierController::resetPassword
 * @see app/Http/Controllers/CashierController.php:83
 * @route '/cashiers/{cashier}/reset-password'
 */
        resetPasswordForm.post = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetPassword.url(args, options),
            method: 'post',
        })
    
    resetPassword.form = resetPasswordForm
/**
* @see \App\Http\Controllers\CashierController::index
 * @see app/Http/Controllers/CashierController.php:22
 * @route '/cashiers'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/cashiers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CashierController::index
 * @see app/Http/Controllers/CashierController.php:22
 * @route '/cashiers'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CashierController::index
 * @see app/Http/Controllers/CashierController.php:22
 * @route '/cashiers'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CashierController::index
 * @see app/Http/Controllers/CashierController.php:22
 * @route '/cashiers'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CashierController::index
 * @see app/Http/Controllers/CashierController.php:22
 * @route '/cashiers'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CashierController::index
 * @see app/Http/Controllers/CashierController.php:22
 * @route '/cashiers'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CashierController::index
 * @see app/Http/Controllers/CashierController.php:22
 * @route '/cashiers'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CashierController::store
 * @see app/Http/Controllers/CashierController.php:42
 * @route '/cashiers'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/cashiers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CashierController::store
 * @see app/Http/Controllers/CashierController.php:42
 * @route '/cashiers'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CashierController::store
 * @see app/Http/Controllers/CashierController.php:42
 * @route '/cashiers'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CashierController::store
 * @see app/Http/Controllers/CashierController.php:42
 * @route '/cashiers'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CashierController::store
 * @see app/Http/Controllers/CashierController.php:42
 * @route '/cashiers'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CashierController::update
 * @see app/Http/Controllers/CashierController.php:61
 * @route '/cashiers/{cashier}'
 */
export const update = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/cashiers/{cashier}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CashierController::update
 * @see app/Http/Controllers/CashierController.php:61
 * @route '/cashiers/{cashier}'
 */
update.url = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cashier: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cashier: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cashier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cashier: typeof args.cashier === 'object'
                ? args.cashier.id
                : args.cashier,
                }

    return update.definition.url
            .replace('{cashier}', parsedArgs.cashier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CashierController::update
 * @see app/Http/Controllers/CashierController.php:61
 * @route '/cashiers/{cashier}'
 */
update.put = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CashierController::update
 * @see app/Http/Controllers/CashierController.php:61
 * @route '/cashiers/{cashier}'
 */
update.patch = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CashierController::update
 * @see app/Http/Controllers/CashierController.php:61
 * @route '/cashiers/{cashier}'
 */
    const updateForm = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CashierController::update
 * @see app/Http/Controllers/CashierController.php:61
 * @route '/cashiers/{cashier}'
 */
        updateForm.put = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CashierController::update
 * @see app/Http/Controllers/CashierController.php:61
 * @route '/cashiers/{cashier}'
 */
        updateForm.patch = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CashierController::destroy
 * @see app/Http/Controllers/CashierController.php:97
 * @route '/cashiers/{cashier}'
 */
export const destroy = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/cashiers/{cashier}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CashierController::destroy
 * @see app/Http/Controllers/CashierController.php:97
 * @route '/cashiers/{cashier}'
 */
destroy.url = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cashier: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cashier: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cashier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cashier: typeof args.cashier === 'object'
                ? args.cashier.id
                : args.cashier,
                }

    return destroy.definition.url
            .replace('{cashier}', parsedArgs.cashier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CashierController::destroy
 * @see app/Http/Controllers/CashierController.php:97
 * @route '/cashiers/{cashier}'
 */
destroy.delete = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CashierController::destroy
 * @see app/Http/Controllers/CashierController.php:97
 * @route '/cashiers/{cashier}'
 */
    const destroyForm = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CashierController::destroy
 * @see app/Http/Controllers/CashierController.php:97
 * @route '/cashiers/{cashier}'
 */
        destroyForm.delete = (args: { cashier: number | { id: number } } | [cashier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const cashiers = {
    deactivate: Object.assign(deactivate, deactivate),
resetPassword: Object.assign(resetPassword, resetPassword),
index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default cashiers