import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::edit
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:16
 * @route '/force-password-reset'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/force-password-reset',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::edit
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:16
 * @route '/force-password-reset'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::edit
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:16
 * @route '/force-password-reset'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::edit
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:16
 * @route '/force-password-reset'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::edit
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:16
 * @route '/force-password-reset'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::edit
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:16
 * @route '/force-password-reset'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::edit
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:16
 * @route '/force-password-reset'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::update
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:28
 * @route '/force-password-reset'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/force-password-reset',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::update
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:28
 * @route '/force-password-reset'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::update
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:28
 * @route '/force-password-reset'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::update
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:28
 * @route '/force-password-reset'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\ForcePasswordResetController::update
 * @see app/Http/Controllers/Auth/ForcePasswordResetController.php:28
 * @route '/force-password-reset'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const force = {
    edit: Object.assign(edit, edit),
update: Object.assign(update, update),
}

export default force