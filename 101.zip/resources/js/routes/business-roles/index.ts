import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessRoleController::index
 * @see app/Http/Controllers/BusinessRoleController.php:18
 * @route '/business-roles'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/business-roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessRoleController::index
 * @see app/Http/Controllers/BusinessRoleController.php:18
 * @route '/business-roles'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessRoleController::index
 * @see app/Http/Controllers/BusinessRoleController.php:18
 * @route '/business-roles'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BusinessRoleController::index
 * @see app/Http/Controllers/BusinessRoleController.php:18
 * @route '/business-roles'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BusinessRoleController::index
 * @see app/Http/Controllers/BusinessRoleController.php:18
 * @route '/business-roles'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BusinessRoleController::index
 * @see app/Http/Controllers/BusinessRoleController.php:18
 * @route '/business-roles'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BusinessRoleController::index
 * @see app/Http/Controllers/BusinessRoleController.php:18
 * @route '/business-roles'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\BusinessRoleController::store
 * @see app/Http/Controllers/BusinessRoleController.php:36
 * @route '/business-roles'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/business-roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BusinessRoleController::store
 * @see app/Http/Controllers/BusinessRoleController.php:36
 * @route '/business-roles'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessRoleController::store
 * @see app/Http/Controllers/BusinessRoleController.php:36
 * @route '/business-roles'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\BusinessRoleController::store
 * @see app/Http/Controllers/BusinessRoleController.php:36
 * @route '/business-roles'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessRoleController::store
 * @see app/Http/Controllers/BusinessRoleController.php:36
 * @route '/business-roles'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\BusinessRoleController::update
 * @see app/Http/Controllers/BusinessRoleController.php:47
 * @route '/business-roles/{businessRole}'
 */
export const update = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/business-roles/{businessRole}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\BusinessRoleController::update
 * @see app/Http/Controllers/BusinessRoleController.php:47
 * @route '/business-roles/{businessRole}'
 */
update.url = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { businessRole: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { businessRole: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    businessRole: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        businessRole: typeof args.businessRole === 'object'
                ? args.businessRole.id
                : args.businessRole,
                }

    return update.definition.url
            .replace('{businessRole}', parsedArgs.businessRole.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessRoleController::update
 * @see app/Http/Controllers/BusinessRoleController.php:47
 * @route '/business-roles/{businessRole}'
 */
update.put = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\BusinessRoleController::update
 * @see app/Http/Controllers/BusinessRoleController.php:47
 * @route '/business-roles/{businessRole}'
 */
update.patch = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\BusinessRoleController::update
 * @see app/Http/Controllers/BusinessRoleController.php:47
 * @route '/business-roles/{businessRole}'
 */
    const updateForm = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessRoleController::update
 * @see app/Http/Controllers/BusinessRoleController.php:47
 * @route '/business-roles/{businessRole}'
 */
        updateForm.put = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\BusinessRoleController::update
 * @see app/Http/Controllers/BusinessRoleController.php:47
 * @route '/business-roles/{businessRole}'
 */
        updateForm.patch = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\BusinessRoleController::destroy
 * @see app/Http/Controllers/BusinessRoleController.php:55
 * @route '/business-roles/{businessRole}'
 */
export const destroy = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/business-roles/{businessRole}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\BusinessRoleController::destroy
 * @see app/Http/Controllers/BusinessRoleController.php:55
 * @route '/business-roles/{businessRole}'
 */
destroy.url = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { businessRole: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { businessRole: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    businessRole: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        businessRole: typeof args.businessRole === 'object'
                ? args.businessRole.id
                : args.businessRole,
                }

    return destroy.definition.url
            .replace('{businessRole}', parsedArgs.businessRole.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessRoleController::destroy
 * @see app/Http/Controllers/BusinessRoleController.php:55
 * @route '/business-roles/{businessRole}'
 */
destroy.delete = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\BusinessRoleController::destroy
 * @see app/Http/Controllers/BusinessRoleController.php:55
 * @route '/business-roles/{businessRole}'
 */
    const destroyForm = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessRoleController::destroy
 * @see app/Http/Controllers/BusinessRoleController.php:55
 * @route '/business-roles/{businessRole}'
 */
        destroyForm.delete = (args: { businessRole: number | { id: number } } | [businessRole: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const businessRoles = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default businessRoles