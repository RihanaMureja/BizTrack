import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import subscription from './subscription'
/**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/businesses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BusinessManagementController::index
 * @see app/Http/Controllers/BusinessManagementController.php:21
 * @route '/admin/businesses'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const businesses = {
    index: Object.assign(index, index),
subscription: Object.assign(subscription, subscription),
}

export default businesses