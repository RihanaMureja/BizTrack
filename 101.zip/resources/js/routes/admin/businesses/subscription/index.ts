import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessManagementController::update
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
export const update = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/businesses/{business}/subscription',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BusinessManagementController::update
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
update.url = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { business: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { business: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    business: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        business: typeof args.business === 'object'
                ? args.business.id
                : args.business,
                }

    return update.definition.url
            .replace('{business}', parsedArgs.business.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessManagementController::update
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
update.put = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\BusinessManagementController::update
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
    const updateForm = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessManagementController::update
 * @see app/Http/Controllers/BusinessManagementController.php:41
 * @route '/admin/businesses/{business}/subscription'
 */
        updateForm.put = (args: { business: number | { id: number } } | [business: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const subscription = {
    update: Object.assign(update, update),
}

export default subscription