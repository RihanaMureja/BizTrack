import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import auditLogs from './audit-logs'
import businesses from './businesses'
import users from './users'
import subscriptions from './subscriptions'
import roles from './roles'
import permissions from './permissions'
/**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SuperAdminController::__invoke
 * @see app/Http/Controllers/SuperAdminController.php:18
 * @route '/admin'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
const admin = {
    auditLogs: Object.assign(auditLogs, auditLogs),
dashboard: Object.assign(dashboard, dashboard),
businesses: Object.assign(businesses, businesses),
users: Object.assign(users, users),
subscriptions: Object.assign(subscriptions, subscriptions),
roles: Object.assign(roles, roles),
permissions: Object.assign(permissions, permissions),
}

export default admin