import business from './business'
const settings = {
    business: Object.assign(business, business),
}

export default settings