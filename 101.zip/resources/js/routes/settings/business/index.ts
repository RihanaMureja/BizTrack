import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\BusinessController::edit
 * @see app/Http/Controllers/BusinessController.php:22
 * @route '/settings/business'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/business',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BusinessController::edit
 * @see app/Http/Controllers/BusinessController.php:22
 * @route '/settings/business'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessController::edit
 * @see app/Http/Controllers/BusinessController.php:22
 * @route '/settings/business'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BusinessController::edit
 * @see app/Http/Controllers/BusinessController.php:22
 * @route '/settings/business'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BusinessController::edit
 * @see app/Http/Controllers/BusinessController.php:22
 * @route '/settings/business'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BusinessController::edit
 * @see app/Http/Controllers/BusinessController.php:22
 * @route '/settings/business'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BusinessController::edit
 * @see app/Http/Controllers/BusinessController.php:22
 * @route '/settings/business'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:34
 * @route '/settings/business'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/business',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:34
 * @route '/settings/business'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:34
 * @route '/settings/business'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:34
 * @route '/settings/business'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessController::store
 * @see app/Http/Controllers/BusinessController.php:34
 * @route '/settings/business'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:42
 * @route '/settings/business'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/business',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:42
 * @route '/settings/business'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:42
 * @route '/settings/business'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:42
 * @route '/settings/business'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BusinessController::update
 * @see app/Http/Controllers/BusinessController.php:42
 * @route '/settings/business'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const business = {
    edit: Object.assign(edit, edit),
store: Object.assign(store, store),
update: Object.assign(update, update),
}

export default business