import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerCreditController::overdue
 * @see app/Http/Controllers/CustomerCreditController.php:19
 * @route '/customer-credits/{customerCredit}/overdue'
 */
export const overdue = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: overdue.url(args, options),
    method: 'post',
})

overdue.definition = {
    methods: ["post"],
    url: '/customer-credits/{customerCredit}/overdue',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerCreditController::overdue
 * @see app/Http/Controllers/CustomerCreditController.php:19
 * @route '/customer-credits/{customerCredit}/overdue'
 */
overdue.url = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customerCredit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customerCredit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customerCredit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customerCredit: typeof args.customerCredit === 'object'
                ? args.customerCredit.id
                : args.customerCredit,
                }

    return overdue.definition.url
            .replace('{customerCredit}', parsedArgs.customerCredit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerCreditController::overdue
 * @see app/Http/Controllers/CustomerCreditController.php:19
 * @route '/customer-credits/{customerCredit}/overdue'
 */
overdue.post = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: overdue.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CustomerCreditController::overdue
 * @see app/Http/Controllers/CustomerCreditController.php:19
 * @route '/customer-credits/{customerCredit}/overdue'
 */
    const overdueForm = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: overdue.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CustomerCreditController::overdue
 * @see app/Http/Controllers/CustomerCreditController.php:19
 * @route '/customer-credits/{customerCredit}/overdue'
 */
        overdueForm.post = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: overdue.url(args, options),
            method: 'post',
        })
    
    overdue.form = overdueForm
/**
* @see \App\Http\Controllers\CustomerCreditController::remind
 * @see app/Http/Controllers/CustomerCreditController.php:28
 * @route '/customer-credits/{customerCredit}/remind'
 */
export const remind = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: remind.url(args, options),
    method: 'post',
})

remind.definition = {
    methods: ["post"],
    url: '/customer-credits/{customerCredit}/remind',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerCreditController::remind
 * @see app/Http/Controllers/CustomerCreditController.php:28
 * @route '/customer-credits/{customerCredit}/remind'
 */
remind.url = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customerCredit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customerCredit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customerCredit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customerCredit: typeof args.customerCredit === 'object'
                ? args.customerCredit.id
                : args.customerCredit,
                }

    return remind.definition.url
            .replace('{customerCredit}', parsedArgs.customerCredit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerCreditController::remind
 * @see app/Http/Controllers/CustomerCreditController.php:28
 * @route '/customer-credits/{customerCredit}/remind'
 */
remind.post = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: remind.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CustomerCreditController::remind
 * @see app/Http/Controllers/CustomerCreditController.php:28
 * @route '/customer-credits/{customerCredit}/remind'
 */
    const remindForm = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: remind.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CustomerCreditController::remind
 * @see app/Http/Controllers/CustomerCreditController.php:28
 * @route '/customer-credits/{customerCredit}/remind'
 */
        remindForm.post = (args: { customerCredit: number | { id: number } } | [customerCredit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: remind.url(args, options),
            method: 'post',
        })
    
    remind.form = remindForm
const customerCredits = {
    overdue: Object.assign(overdue, overdue),
remind: Object.assign(remind, remind),
}

export default customerCredits