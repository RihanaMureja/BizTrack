import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SecurityQuestionController::edit
 * @see app/Http/Controllers/SecurityQuestionController.php:16
 * @route '/settings/security-questions'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/security-questions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SecurityQuestionController::edit
 * @see app/Http/Controllers/SecurityQuestionController.php:16
 * @route '/settings/security-questions'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SecurityQuestionController::edit
 * @see app/Http/Controllers/SecurityQuestionController.php:16
 * @route '/settings/security-questions'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SecurityQuestionController::edit
 * @see app/Http/Controllers/SecurityQuestionController.php:16
 * @route '/settings/security-questions'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SecurityQuestionController::edit
 * @see app/Http/Controllers/SecurityQuestionController.php:16
 * @route '/settings/security-questions'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SecurityQuestionController::edit
 * @see app/Http/Controllers/SecurityQuestionController.php:16
 * @route '/settings/security-questions'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SecurityQuestionController::edit
 * @see app/Http/Controllers/SecurityQuestionController.php:16
 * @route '/settings/security-questions'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\SecurityQuestionController::store
 * @see app/Http/Controllers/SecurityQuestionController.php:28
 * @route '/settings/security-questions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/security-questions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SecurityQuestionController::store
 * @see app/Http/Controllers/SecurityQuestionController.php:28
 * @route '/settings/security-questions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SecurityQuestionController::store
 * @see app/Http/Controllers/SecurityQuestionController.php:28
 * @route '/settings/security-questions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SecurityQuestionController::store
 * @see app/Http/Controllers/SecurityQuestionController.php:28
 * @route '/settings/security-questions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SecurityQuestionController::store
 * @see app/Http/Controllers/SecurityQuestionController.php:28
 * @route '/settings/security-questions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const securityQuestions = {
    edit: Object.assign(edit, edit),
store: Object.assign(store, store),
}

export default securityQuestions